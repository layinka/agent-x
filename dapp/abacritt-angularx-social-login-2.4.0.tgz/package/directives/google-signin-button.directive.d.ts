import { ElementRef } from '@angular/core';
import { SocialAuthService } from '../socialauth.service';
import * as i0 from "@angular/core";
export declare class GoogleSigninButtonDirective {
    type: 'icon' | 'standard';
    size: 'small' | 'medium' | 'large';
    text: 'signin_with' | 'signup_with' | 'continue_with';
    shape: 'square' | 'circle' | 'pill' | 'rectangular';
    theme: 'outline' | 'filled_blue' | 'filled_black';
    logo_alignment: 'left' | 'center';
    width: number;
    locale: string;
    constructor(el: ElementRef, socialAuthService: SocialAuthService);
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleSigninButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<GoogleSigninButtonDirective, "asl-google-signin-button", never, { "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "text": { "alias": "text"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "logo_alignment": { "alias": "logo_alignment"; "required": false; }; "width": { "alias": "width"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; }, {}, never, never, true, never>;
}
